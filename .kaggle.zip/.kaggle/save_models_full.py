import os
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

os.makedirs("models", exist_ok=True)

# --- Load engineered dataset ---
df = pd.read_csv("data/engineered/engineered_dataset.csv")
# Selected features used in earlier steps
features = [
    "Matches_Played","Goals_For","Goals_Against","Goal_Diff",
    "Goals_Per_Match","Goals_Against_Per_Match","Win_Rate_Proxy",
    "Attack_Defense_Ratio","FIFA_Strength","FIFA_Points_Per_Match"
]
target = "is_finalist"

# Ensure features exist
missing = [f for f in features if f not in df.columns]
if missing:
    raise SystemExit(f"Missing features in engineered dataset: {missing}")

X = df[features].copy()
y = df[target].astype(int)

# Split (same seed as before)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

scaler = StandardScaler()
scaler.fit(X_train)
joblib.dump(scaler, "models/scaler.joblib")
print("Saved scaler -> models/scaler.joblib")

# Scale for logistic training
X_train_scaled = scaler.transform(X_train)
X_test_scaled = scaler.transform(X_test)

# --- Train and save Logistic Regression ---
log_model = LogisticRegression(max_iter=2000, class_weight='balanced', random_state=42)
log_model.fit(X_train_scaled, y_train)
joblib.dump(log_model, "models/logistic.joblib")
print("Saved logistic -> models/logistic.joblib")

# --- Train and tune Random Forest (GridSearchCV) ---
rf = RandomForestClassifier(random_state=42, class_weight='balanced')
param_grid = {
    "n_estimators": [100, 200],
    "max_depth": [None, 6, 12],
    "min_samples_split": [2, 5]
}
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
grid = GridSearchCV(rf, param_grid, scoring="roc_auc", cv=cv, n_jobs=-1, verbose=1)
print("Running GridSearchCV for Random Forest (this may take a short while)...")
grid.fit(X_train, y_train)

best_rf = grid.best_estimator_
joblib.dump(best_rf, "models/best_rf.joblib")
print("Saved best RF -> models/best_rf.joblib")
print("Best RF params:", grid.best_params_)
