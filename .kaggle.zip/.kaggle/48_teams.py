# make_teams_48.py
import pandas as pd
import os

print("\n===== FIFA 2026 TEAM SELECTION (28 qualified + 20 predicted) =====\n")

# Load engineered dataset (has all required features)
df = pd.read_csv("data/engineered/engineered_dataset.csv")

# Keep ONLY the most recent record per team (latest year)
df = df.sort_values(["Team", "Year"], ascending=[True, False]).drop_duplicates("Team", keep="first")

#  28 CONFIRMED TEAMS (as per professor note)
qualified_28 = [
    "Argentina", "Brazil", "Uruguay", "Ecuador",
    "United States", "Mexico", "Canada",
    "France", "Spain", "Germany", "England",
    "Netherlands", "Portugal", "Italy",
    "Switzerland", "Croatia", "Belgium", "Serbia",
    "Poland", "Denmark",
    "Japan", "South Korea", "Iran", "Saudi Arabia",
    "Morocco", "Senegal", "Nigeria", "South Africa"
]

# Filter only teams found in dataset
df_28 = df[df["Team"].isin(qualified_28)]

print("QUALIFIED TEAMS (28):")
print(df_28["Team"].to_list())
print("\nTotal qualified found:", len(df_28))

# Remaining teams (not in top 28)
remaining = df[~df["Team"].isin(qualified_28)].copy()

# Select TOP 20 strongest teams using FIFA_Strength
df_20 = remaining.sort_values("FIFA_Strength", ascending=False).head(20)

print("\n PREDICTED LIKELY TEAMS (Top 20 by strength):")
print(df_20["Team"].to_list())
print("\nTotal predicted:", len(df_20))

#  Combine datasets → 48 teams
df_48 = pd.concat([df_28, df_20], ignore_index=True).drop_duplicates("Team", keep="first")

print("\n FINAL LIST OF 48 TEAMS (for prediction):")
print(df_48["Team"].to_list())
print("\nTotal:", len(df_48))

#  Ensure folder exists
os.makedirs("data/final", exist_ok=True)

#  Save outputs
df_28.to_csv("data/final/qualified_28.csv", index=False)
df_20.to_csv("data/final/predicted_20.csv", index=False)
df_48.to_csv("data/final/teams_48.csv", index=False)

print("\n Saved all files inside data/final/:")
print("- qualified_28.csv")
print("- predicted_20.csv")
print("- teams_48.csv")
print("\n DONE\n")
