import pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("data/engineered/engineered_dataset.csv")

features = [
    "Matches_Played","Goals_For","Goals_Against","Goal_Diff",
    "Goals_Per_Match","Goals_Against_Per_Match","Win_Rate_Proxy",
    "Attack_Defense_Ratio","FIFA_Strength","FIFA_Points_Per_Match"
]
target = "is_finalist"

X = df[features]
y = df[target]

# Stratified split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

print(" Train/Test Split complete")
print("Training size:", X_train.shape)
print("Testing size:", X_test.shape)
print("Class balance (train):")
print(y_train.value_counts(normalize=True))
