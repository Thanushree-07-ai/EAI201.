import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

df = pd.read_csv("data/engineered/engineered_dataset.csv")

features = [
    "Matches_Played","Goals_For","Goals_Against","Goal_Diff",
    "Goals_Per_Match","Goals_Against_Per_Match","Win_Rate_Proxy",
    "Attack_Defense_Ratio","FIFA_Strength","FIFA_Points_Per_Match"
]
target = "is_finalist"

X = df[features]
y = df[target]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

print(" Data scaled successfully!")
print("Mean of scaled train features (approx 0):", X_train_scaled.mean().round(3))
print("Std of scaled train features (approx 1):", X_train_scaled.std().round(3))
