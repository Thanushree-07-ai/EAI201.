import pandas as pd
import numpy as np
import os

# Load cleaned dataset
df = pd.read_csv("data/clean/cleaned_dataset.csv")
print(" Loaded cleaned dataset:", df.shape)

# --- Feature Engineering ---

# Goals per match
df['Goals_Per_Match'] = df['Goals_For'] / df['Matches_Played']

# Goals conceded per match
df['Goals_Against_Per_Match'] = df['Goals_Against'] / df['Matches_Played']

# Win rate proxy (approximation using goal difference)
df['Win_Rate_Proxy'] = ((df['Goal_Diff'] / df['Matches_Played']) + 1) / 2
df['Win_Rate_Proxy'] = df['Win_Rate_Proxy'].clip(0, 1)

# Attack-to-defense ratio
df['Attack_Defense_Ratio'] = df['Goals_For'] / (df['Goals_Against'] + 1)

# FIFA Strength: smaller rank = stronger → invert
df['FIFA_Strength'] = df['FIFA_Rank'].max() - df['FIFA_Rank'] + 1

# FIFA points per match
df['FIFA_Points_Per_Match'] = df['FIFA_Points'] / df['Matches_Played']

# Replace inf/nan values
df = df.replace([np.inf, -np.inf], np.nan).fillna(0)

# Save engineered dataset
os.makedirs("data/engineered", exist_ok=True)
df.to_csv("data/engineered/engineered_dataset.csv", index=False)

print(" Feature engineering complete!")
print("New columns added:")
print([col for col in df.columns if col not in ['Year','Team','is_finalist']][:8])
print("\n Saved to: data/engineered/engineered_dataset.csv")
