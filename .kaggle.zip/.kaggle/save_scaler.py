import pandas as pd
import os
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

#  Ensure models folder exists
os.makedirs("models", exist_ok=True)

#  Load engineered dataset
df = pd.read_csv("data/engineered/engineered_dataset.csv")

#  Define features (same as used in Task 2)
features = [
    "Matches_Played","Goals_For","Goals_Against","Goal_Diff",
    "Goals_Per_Match","Goals_Against_Per_Match","Win_Rate_Proxy",
    "Attack_Defense_Ratio","FIFA_Strength","FIFA_Points_Per_Match"
]
target = "is_finalist"

#  Split into train/test
X = df[features]
y = df[target]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

#  Fit scaler on training data
scaler = StandardScaler()
scaler.fit(X_train)

#  Save scaler
joblib.dump(scaler, "models/scaler.joblib")
print(" Scaler recreated and saved successfully at 'models/scaler.joblib'")
