import joblib
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load Random Forest model (best_rf.joblib)
rf_model = joblib.load("models/best_rf.joblib")

# Load Logistic Regression model
log_model = joblib.load("models/logistic.joblib")

# Define features (same as used in training)
features = [
    "Matches_Played", "Goals_For", "Goals_Against", "Goal_Diff",
    "Goals_Per_Match", "Goals_Against_Per_Match", "Win_Rate_Proxy",
    "Attack_Defense_Ratio", "FIFA_Strength", "FIFA_Points_Per_Match"
]

# --- Random Forest Feature Importance ---
rf_importance = pd.DataFrame({
    "Feature": features,
    "Importance": rf_model.feature_importances_
}).sort_values(by="Importance", ascending=False)

plt.figure(figsize=(8,5))
sns.barplot(x="Importance", y="Feature", data=rf_importance, palette="viridis")
plt.title("Random Forest Feature Importance")
plt.tight_layout()
plt.savefig("models/random_forest_feature_importance.png")
plt.show()

# --- Logistic Regression Coefficients ---
log_importance = pd.DataFrame({
    "Feature": features,
    "Coefficient": log_model.coef_[0]
}).sort_values(by="Coefficient", ascending=False)

plt.figure(figsize=(8,5))
sns.barplot(x="Coefficient", y="Feature", data=log_importance, palette="coolwarm")
plt.title("Logistic Regression Feature Coefficients")
plt.tight_layout()
plt.savefig("models/logistic_regression_coefficients.png")
plt.show()

print("\n Feature importance visualizations saved successfully!")
