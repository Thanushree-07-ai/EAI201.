import pandas as pd

df = pd.read_csv("data/engineered/engineered_dataset.csv")

# Select features based on domain knowledge
features = [
    "Matches_Played", "Goals_For", "Goals_Against", "Goal_Diff",
    "Goals_Per_Match", "Goals_Against_Per_Match", "Win_Rate_Proxy",
    "Attack_Defense_Ratio", "FIFA_Strength", "FIFA_Points_Per_Match"
]
target = "is_finalist"

X = df[features]
y = df[target]

print(" Features and target defined")
print("Feature columns:", features)
print("Target:", target)
print("\nFeature sample:")
print(X.head())
print("\nTarget sample:")
print(y.head())
