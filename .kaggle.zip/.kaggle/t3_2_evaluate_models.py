import joblib, pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, classification_report, roc_curve
import matplotlib.pyplot as plt
import seaborn as sns

# Load
scaler = joblib.load("models/scaler.joblib")
log_model = joblib.load("models/logistic.joblib")
rf_model = joblib.load("models/best_rf.joblib")
df = pd.read_csv("data/engineered/engineered_dataset.csv")

features = ["Matches_Played","Goals_For","Goals_Against","Goal_Diff",
            "Goals_Per_Match","Goals_Against_Per_Match","Win_Rate_Proxy",
            "Attack_Defense_Ratio","FIFA_Strength","FIFA_Points_Per_Match"]
target = "is_finalist"

X = df[features]
y = df[target]

# scaled input for logistic
X_scaled = scaler.transform(X)

# predictions & probs
y_pred_log = log_model.predict(X_scaled)
y_prob_log = log_model.predict_proba(X_scaled)[:,1]

y_pred_rf = rf_model.predict(X)            # RF trained on raw features
y_prob_rf = rf_model.predict_proba(X)[:,1]

# helper
def print_metrics(name, y_true, y_pred, y_proba):
    print(f"\n=== {name} ===")
    print("Accuracy:", round(accuracy_score(y_true,y_pred),3))
    print("Precision:", round(precision_score(y_true,y_pred),3))
    print("Recall:", round(recall_score(y_true,y_pred),3))
    print("F1:", round(f1_score(y_true,y_pred),3))
    print("ROC-AUC:", round(roc_auc_score(y_true,y_proba),3))
    print("\nClassification Report:\n", classification_report(y_true,y_pred))

# print metrics
print_metrics("Logistic Regression", y, y_pred_log, y_prob_log)
print_metrics("Random Forest", y, y_pred_rf, y_prob_rf)

# confusion matrices
for name, y_pred in [("Logistic Regression", y_pred_log), ("Random Forest", y_pred_rf)]:
    cm = confusion_matrix(y, y_pred)
    plt.figure(figsize=(4,3))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False)
    plt.title(f"{name} Confusion Matrix")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.tight_layout()
    plt.savefig(f"models/{name.replace(' ','_')}_confusion.png")
    plt.show()

# ROC comparison
fpr_log, tpr_log, _ = roc_curve(y, y_prob_log)
fpr_rf, tpr_rf, _ = roc_curve(y, y_prob_rf)
plt.figure(figsize=(6,5))
plt.plot(fpr_log, tpr_log, label=f"Logistic (AUC={roc_auc_score(y,y_prob_log):.3f})")
plt.plot(fpr_rf, tpr_rf, label=f"RandomForest (AUC={roc_auc_score(y,y_prob_rf):.3f})")
plt.plot([0,1],[0,1],'--', color='gray')
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve Comparison")
plt.legend()
plt.tight_layout()
plt.savefig("models/roc_comparison.png")
plt.show()
