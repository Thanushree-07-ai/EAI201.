import pandas as pd

df = pd.read_csv("data/clean/cleaned_dataset.csv")

print(" Loaded cleaned_dataset.csv successfully!")
print(f"Rows: {len(df)}, Columns: {len(df.columns)}")
print("\nColumn names:\n", df.columns.tolist())
print("\nSample:\n", df.head(5))

# Check missing values
print("\n--- Missing Values ---")
print(df.isna().sum())

# Check duplicates
dupes = df.duplicated(subset=['Year', 'Team']).sum()
print(f"\nDuplicate rows (same Year+Team): {dupes}")

# Check data types
print("\n--- Data Types ---")
print(df.dtypes)

# Check invalid values
invalid_goals = df[(df['Goals_For'] < 0) | (df['Goals_Against'] < 0)]
print(f"\nNegative goal counts: {len(invalid_goals)}")

# Basic statistics
print("\n--- Basic Statistics ---")
print(df.describe())

# Check reasonable range for ranks
if 'FIFA_Rank' in df.columns:
    print("\nFIFA Rank range:", df['FIFA_Rank'].min(), "to", df['FIFA_Rank'].max())

# Check how many finalists per year
print("\nFinalists per Year:")
print(df.groupby('Year')['is_finalist'].sum())
