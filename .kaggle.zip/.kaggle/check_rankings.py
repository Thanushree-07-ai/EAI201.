import pandas as pd

df = pd.read_csv("data/fifa_ranking-2023-07-20.csv")
print(" Loaded FIFA ranking dataset successfully!")
print(df.head())
print("\nColumns:", list(df.columns))
