import pandas as pd

# Load engineered dataset
df = pd.read_csv("data/engineered/engineered_dataset.csv")

print(" Dataset loaded successfully!")
print("Shape:", df.shape)
print("\nColumns:\n", df.columns.tolist())
print("\nSample rows:")
print(df.head())
