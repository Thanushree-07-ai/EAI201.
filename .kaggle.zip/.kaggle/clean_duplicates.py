import pandas as pd

# Load your cleaned dataset
df = pd.read_csv("data/clean/cleaned_dataset.csv")

print("Before removing duplicates:", df.shape)

# Drop duplicates based on Year + Team
df = df.drop_duplicates(subset=['Year', 'Team'], keep='first')

print("After removing duplicates:", df.shape)

# Save it back
df.to_csv("data/clean/cleaned_dataset.csv", index=False)
print(" Duplicates removed and file saved successfully!")
