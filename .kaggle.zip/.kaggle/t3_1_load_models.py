import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Load data
df = pd.read_csv("data/engineered/engineered_dataset.csv")

# Define features and target
features = [
    "Matches_Played","Goals_For","Goals_Against","Goal_Diff",
    "Goals_Per_Match","Goals_Against_Per_Match","Win_Rate_Proxy",
    "Attack_Defense_Ratio","FIFA_Strength","FIFA_Points_Per_Match"
]
target = "is_finalist"

X = df[features]
y = df[target]

# Split (same as Task 2)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Load trained models and scaler
scaler = joblib.load("models/scaler.joblib")
log_model = joblib.load("models/logistic.joblib")
rf_model = joblib.load("models/best_rf.joblib")

# Scale test data
X_test_scaled = scaler.transform(X_test)

print("Models and test data loaded successfully!")
print("Test data shape:", X_test.shape)
