import joblib, os
files = ["models/scaler.joblib", "models/logistic.joblib", "models/best_rf.joblib"]
for p in files:
    print(p, "FOUND" if os.path.exists(p) else "MISSING, check path")
print("\nAttempting to load objects:")
scaler = joblib.load("models/scaler.joblib")
print("Scaler loaded. mean_ length:", len(getattr(scaler, "mean_", [])))
log = joblib.load("models/logistic.joblib")
print("Logistic loaded. class:", type(log).__name__, "coef shape:", getattr(log,"coef_", "N/A").shape)
rf = joblib.load("models/best_rf.joblib")
print("RF loaded. class:", type(rf).__name__, "n_estimators:", getattr(rf, "n_estimators", "N/A"))
