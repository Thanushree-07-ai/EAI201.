import os
import io
import pandas as pd
from kaggle.api.kaggle_api_extended import KaggleApi

# STEP 1: Authenticate Kaggle
print("Authenticating Kaggle API...")
api = KaggleApi()
api.authenticate()
print("Authentication successful!\n")

# STEP 2: Specify the Kaggle dataset
# Kaggle URL: https://www.kaggle.com/datasets/abecklas/fifa-world-cup
DATASET_SLUG = "abecklas/fifa-world-cup"  # <-- Updated to your link

# STEP 3: Create local folder to store the data
DATA_PATH = "data"
os.makedirs(DATA_PATH, exist_ok=True)

# STEP 4: Download dataset from Kaggle
print("Downloading dataset from Kaggle...")
api.dataset_download_files(DATASET_SLUG, path=DATA_PATH, unzip=True)
print("Download complete!\n")

#  STEP 5: Locate CSV file
csv_file = None
for file in os.listdir(DATA_PATH):
    if file.endswith(".csv"):
        csv_file = os.path.join(DATA_PATH, file)
        break

if not csv_file:
    raise FileNotFoundError("❌ No CSV file found after download!")

print(f" Found CSV file: {csv_file}\n")

#  STEP 6: Load CSV safely with pandas
with open(csv_file, "r", encoding="utf-8", errors="ignore") as f:
    data_str = f.read()

data_io = io.StringIO(data_str)
df = pd.read_csv(data_io, sep=None, engine="python", on_bad_lines="skip")

#  STEP 7: Show data summary
print(" Dataset loaded successfully!")
print(f"Rows: {len(df)}, Columns: {len(df.columns)}\n")
print(" Preview:")
print(df.head())

#  STEP 8: (Optional) Save cleaned file
OUTPUT_FILE = os.path.join(DATA_PATH, "fifa_world_cup_clean.csv")
df.to_csv(OUTPUT_FILE, index=False)
print(f"\n Saved to: {OUTPUT_FILE}")
