import pandas as pd
import joblib

rf = joblib.load("models/best_rf.joblib")
scaler = joblib.load("models/scaler.joblib")

# the columns the scaler was fitted on (ensures perfect match)
expected_features = list(getattr(scaler, "feature_names_in_", []))
if not expected_features:
    # fallback if your sklearn version lacks feature_names_in_
    expected_features = [
        "Matches_Played","Goals_For","Goals_Against","Goal_Diff",
        "Goals_Per_Match","Goals_Against_Per_Match","Win_Rate_Proxy",
        "Attack_Defense_Ratio","FIFA_Strength","FIFA_Points","FIFA_Rank","FIFA_Points_Per_Match"
    ]

teams_48 = pd.read_csv("data/final/teams_48.csv")
team_names = teams_48["Team"] if "Team" in teams_48.columns else teams_48.iloc[:,0]

# --- load engineered base and filter to latest row per team
base = pd.read_csv("data/engineered/engineered_dataset.csv")
base_latest = (
    base.sort_values(["Team","Year"], ascending=[True, False])
        .drop_duplicates("Team", keep="first")
)

df = base_latest[base_latest["Team"].isin(team_names)].copy()

# ensure we have all expected columns
missing = [c for c in expected_features if c not in df.columns]
if missing:
    print(" Missing columns in engineered data, creating neutral fillers:", missing)
    for c in missing:
        df[c] = 0.0

# --- build the exact X in the same column order
X = df[expected_features]

# --- scale & predict
X_scaled = scaler.transform(X)
df["Finalist_Probability"] = rf.predict_proba(X_scaled)[:, 1]

# --- sort and print top-2 finalists
df_sorted = df.sort_values("Finalist_Probability", ascending=False)
finalists = df_sorted[["Team","Finalist_Probability"]].head(2)

print("\n FINAL PREDICTED 2026 WORLD CUP FINALISTS:")
print(finalists.to_string(index=False))

# save full ranked list
df_sorted.to_csv("final_predictions_2026.csv", index=False)
print("\n Saved full ranked list to final_predictions_2026.csv")
