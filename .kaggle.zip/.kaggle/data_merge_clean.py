# data_merge_clean_fixed.py
import pandas as pd
import numpy as np
import os

# --- Load datasets ---
matches = pd.read_csv("data/WorldCupMatches.csv", encoding="utf-8", on_bad_lines="skip")
players = pd.read_csv("data/WorldCupPlayers.csv", encoding="utf-8", on_bad_lines="skip")
worldcups = pd.read_csv("data/WorldCups.csv", encoding="utf-8", on_bad_lines="skip")
ranking = pd.read_csv("data/fifa_ranking-2023-07-20.csv", encoding="utf-8", on_bad_lines="skip")

print(" All files loaded successfully!\n")

# Clean column names (strip whitespace)
matches.columns = matches.columns.str.strip()
players.columns = players.columns.str.strip()
worldcups.columns = worldcups.columns.str.strip()
ranking.columns = ranking.columns.str.strip()

# --- quick debug print: show players columns so you can see exact names ----
print("Players file columns:\n", list(players.columns), "\n")
print("Ranking file columns:\n", list(ranking.columns), "\n")

# --- Identify finalists ---
finals = matches[matches['Stage'].str.lower().str.contains('final', na=False)]
final_teams = []
for _, row in finals.iterrows():
    year = row['Year']
    final_teams.append({'Year': year, 'Team': row['Home Team Name']})
    final_teams.append({'Year': year, 'Team': row['Away Team Name']})
finals_df = pd.DataFrame(final_teams)
finals_df['is_finalist'] = 1

# --- Aggregate match-level data into team-year rows ---
match_list = []
for _, row in matches.iterrows():
    year = row['Year']
    home = row['Home Team Name']
    away = row['Away Team Name']
    hg, ag = row['Home Team Goals'], row['Away Team Goals']
    match_list.append({'Year': year, 'Team': home, 'Goals_For': hg, 'Goals_Against': ag})
    match_list.append({'Year': year, 'Team': away, 'Goals_For': ag, 'Goals_Against': hg})

match_data = pd.DataFrame(match_list)
agg = match_data.groupby(['Year', 'Team']).agg(
    Matches_Played=('Goals_For', 'count'),
    Goals_For=('Goals_For', 'sum'),
    Goals_Against=('Goals_Against', 'sum')
).reset_index()
agg['Goal_Diff'] = agg['Goals_For'] - agg['Goals_Against']

# --- Merge finalist label ---
agg = agg.merge(finals_df, on=['Year', 'Team'], how='left')
agg['is_finalist'] = agg['is_finalist'].fillna(0).astype(int)

# --- Robust detection of age/caps columns in players file ---
cols_lower = [c.lower() for c in players.columns]

age_col = None
caps_col = None
# find first column name that contains 'age'
for c in players.columns:
    if 'age' in c.lower():
        age_col = c
        break
# find first column name that contains 'cap' or 'caps'
for c in players.columns:
    if 'cap' in c.lower():
        caps_col = c
        break

print("Detected player-age column:", age_col)
print("Detected player-caps column:", caps_col)
print()

# Build player aggregates only if we detected required columns
player_aggs = None
if age_col is not None or caps_col is not None:
    # normalize column names for grouping
    pl = players.copy()
    # try to find Year and Team column names (flexible)
    year_col = next((c for c in pl.columns if c.lower() == 'year'), None)
    team_col = next((c for c in pl.columns if 'team' in c.lower()), None)
    player_col = next((c for c in pl.columns if 'player' in c.lower()), None)

    if year_col is None or team_col is None:
        print("Warning: Could not find 'Year' or 'Team' columns in players file. Skipping player-level aggregation.")
    else:
        # Rename helpful columns to standardized ones for aggregation
        rename_map = {year_col: 'Year', team_col: 'Team'}
        if age_col:
            rename_map[age_col] = 'Age'
        if caps_col:
            rename_map[caps_col] = 'Caps'
        pl = pl.rename(columns=rename_map)

        # Convert Age/Caps to numeric if present
        if 'Age' in pl.columns:
            pl['Age'] = pd.to_numeric(pl['Age'], errors='coerce')
        if 'Caps' in pl.columns:
            pl['Caps'] = pd.to_numeric(pl['Caps'], errors='coerce')

        # Group and compute averages
        agg_list = {}
        if 'Age' in pl.columns:
            agg_list['Avg_Age'] = ('Age', 'mean')
        if 'Caps' in pl.columns:
            agg_list['Avg_Caps'] = ('Caps', 'mean')

        # also compute squad size (count of players) where player column exists
        if player_col:
            pl = pl.rename(columns={player_col: 'Player'})
            agg_list['Squad_Size'] = ('Player', 'count')
        else:
            # fallback: count rows
            agg_list['Squad_Size'] = (pl.columns[0], 'count')

        player_aggs = pl.groupby(['Year', 'Team']).agg(**agg_list).reset_index()
        print("Player aggregates computed. Sample:")
        print(player_aggs.head())
        # Merge into main agg
        agg = agg.merge(player_aggs, on=['Year', 'Team'], how='left')
else:
    print("No age/caps columns detected in players file; skipping player aggregates.\n")

# --- Prepare ranking file and merge by Team (note: ranking may have many dates) ---
# Standardize ranking columns if present
rank_rename = {}
if 'country_full' in ranking.columns:
    rank_rename['country_full'] = 'Team'
if 'rank' in ranking.columns:
    rank_rename['rank'] = 'FIFA_Rank'
if 'total_points' in ranking.columns:
    rank_rename['total_points'] = 'FIFA_Points'
ranking = ranking.rename(columns=rank_rename)

# Normalize Team names' capitalization and whitespace for matching
agg['Team'] = agg['Team'].astype(str).str.strip().str.title()
if 'Team' in ranking.columns:
    ranking['Team'] = ranking['Team'].astype(str).str.strip().str.title()

# If ranking has multiple dates, pick the most recent per team (or a snapshot)
if 'rank_date' in ranking.columns:
    # convert to datetime and pick latest per team
    ranking['rank_date'] = pd.to_datetime(ranking['rank_date'], errors='coerce')
    latest_rank = ranking.sort_values('rank_date').groupby('Team').tail(1)
else:
    latest_rank = ranking.copy()

# keep only Team, FIFA_Rank, FIFA_Points if they exist
keep_cols = [c for c in ['Team', 'FIFA_Rank', 'FIFA_Points'] if c in latest_rank.columns]
latest_rank = latest_rank[keep_cols].drop_duplicates(subset=['Team'])

agg = agg.merge(latest_rank, on='Team', how='left')

# Fill missing numerical values sensibly
if 'Avg_Age' in agg.columns:
    agg['Avg_Age'] = agg['Avg_Age'].fillna(agg['Avg_Age'].mean())
else:
    agg['Avg_Age'] = np.nan

if 'Avg_Caps' in agg.columns:
    agg['Avg_Caps'] = agg['Avg_Caps'].fillna(agg['Avg_Caps'].mean())
else:
    agg['Avg_Caps'] = np.nan

if 'FIFA_Rank' in agg.columns:
    agg['FIFA_Rank'] = agg['FIFA_Rank'].fillna(agg['FIFA_Rank'].max())
else:
    agg['FIFA_Rank'] = np.nan

if 'FIFA_Points' in agg.columns:
    agg['FIFA_Points'] = agg['FIFA_Points'].fillna(agg['FIFA_Points'].mean())
else:
    agg['FIFA_Points'] = np.nan

# Save the final cleaned dataset
os.makedirs("data/clean", exist_ok=True)
out_fp = "data/clean/cleaned_dataset.csv"
agg.to_csv(out_fp, index=False)

print("\n Cleaned dataset saved to:", out_fp)
print("Preview:")
print(agg.head())
print("\nColumns in cleaned dataset:", list(agg.columns))
